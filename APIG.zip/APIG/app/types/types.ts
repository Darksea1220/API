export interface Character{
    birth_year:string;
    gender:string;
    hair_color:string;
    height:string;
    homeworld:string;
    mass:string;
    name:string;
    skin_color:string;
}
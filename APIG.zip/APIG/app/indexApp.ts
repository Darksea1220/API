import {arreglo} from './Data.js';
import {Character} from './types/types.js';
import './components/indexComp.js';
class MyAppContainer extends HTMLElement{
    constructor(){
        super();
        this.attachShadow({mode: 'open'});
    }

async connectedCallback(){
        const card:any= await arreglo();
        const card2:any[]=[];
        for (let i = 0; i < 5; i++) {
            const e = card [i];
            card2.push(e);
        }
        this.render(card2);
    }
    render(card:Array<Character>){
        if(this.shadowRoot){
            const star=card.map(({birth_year, gender, hair_color, name, skin_color})=>`
            <my-stw birth_year='${birth_year}' gender='${gender}' hair_color='${hair_color}' name='${name}' skin_color='${skin_color}'>
            </my-stw>`);
            this.shadowRoot.innerHTML = `
            <link rel="stylesheet" type="text/css" href="index.css">
            <h1>Starwars 5 personajes</h1>
            ${star.join('')}
            `;
            
        }
    }
}
customElements.define('my-appcontainer', MyAppContainer);

import {Character} from './types/types.js';
export const arreglo=async():Promise<Array<Character>>=>{
    const obtStar=await fetch ('https://swapi.dev/api/people/');
    const data= await obtStar.json();
    console.log(data.results);
    return data.results;
};

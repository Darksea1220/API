var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
import { arreglo } from './Data.js';
import './components/indexComp.js';
class MyAppContainer extends HTMLElement {
    constructor() {
        super();
        this.attachShadow({ mode: 'open' });
    }
    connectedCallback() {
        return __awaiter(this, void 0, void 0, function* () {
            const card = yield arreglo();
            const card2 = [];
            for (let i = 0; i < 5; i++) {
                const e = card[i];
                card2.push(e);
            }
            this.render(card2);
        });
    }
    render(card) {
        if (this.shadowRoot) {
            const star = card.map(({ birth_year, gender, hair_color, name, skin_color }) => `
            <my-stw birth_year='${birth_year}' gender='${gender}' hair_color='${hair_color}' name='${name}' skin_color='${skin_color}'>
            </my-stw>`);
            this.shadowRoot.innerHTML = `
            <link rel="stylesheet" type="text/css" href="index.css">
            <h1>Starwars 5 personajes</h1>
            ${star.join('')}
            `;
        }
    }
}
customElements.define('my-appcontainer', MyAppContainer);
